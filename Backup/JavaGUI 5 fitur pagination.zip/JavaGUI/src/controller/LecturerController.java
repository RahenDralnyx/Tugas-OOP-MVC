/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rahen
 */

package controller;

import java.util.List;
import model.Lecturer;
import dao.LecturerDAO;

public class LecturerController {
    private LecturerDAO lecturerDAO = new LecturerDAO();

    public int create(Lecturer lecturer) { return lecturerDAO.create(lecturer); }
    public List<Lecturer> getLecturer() { return lecturerDAO.getLecturer(); }
    public int update(Lecturer lecturer) { return lecturerDAO.update(lecturer); }
    public int delete(int id) { return lecturerDAO.delete(id); }
    public List<Lecturer> getLecturerPage(int offset, int limit) { return lecturerDAO.getLecturerPage(offset, limit); }
    public int getTotalCount() { return lecturerDAO.getTotalCount(); }
}