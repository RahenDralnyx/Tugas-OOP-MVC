package controller;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rahen
 */

import java.util.List;
import model.Course;
import dao.CourseDAO;

public class CourseController {
    private CourseDAO courseDAO = new CourseDAO();

    public int create(Course course) { return courseDAO.create(course); }
    public List<Course> getCourse() { return courseDAO.getCourse(); }
    public int update(Course course) { return courseDAO.update(course); }
    public int delete(int id) { return courseDAO.delete(id); }
    public List<Course> getCoursePage(int offset, int limit) { return courseDAO.getCoursePage(offset, limit); }
    public int getTotalCount() { return courseDAO.getTotalCount(); }
}