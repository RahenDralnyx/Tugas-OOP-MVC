/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import javaapplication_hello.KRS;
import javaapplication_hello.Person;

/**
 *
 * @author agusseputra
 */
public class Student extends Person {

    private String nim;
    private String studyProgram;
    private ArrayList<KRS> krsList;

    public Student(String idCard, String name, 
            String nim, String studyProgram) {

        super(idCard, name);

        this.nim = nim;
        this.studyProgram = studyProgram;
        krsList = new ArrayList<>();
    }

    @Override
    public String toString() {
        return this.name; 
    }
    public String getNim() {
        return nim;
    }
    public String getCardID() {
        return idCard;
    }

    public String getName() {
        return name;
    }

    public String getStudyProgram() {
        return studyProgram;
    }
    public void addKRS(KRS krs){
        krsList.add(krs);
    }
}
