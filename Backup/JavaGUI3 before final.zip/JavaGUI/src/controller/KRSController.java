/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

/**
 *
 * @author rahen
 */

import java.util.List;
import dao.KRSDAO;

public class KRSController {
    private KRSDAO krsDAO = new KRSDAO();

    public int create(String nim, int courseId, int lecturerId, int semester,
                       int sikap, int uts, int uas, double score, String grade) {
        return krsDAO.create(nim, courseId, lecturerId, semester, sikap, uts, uas, score, grade);
    }

    public int update(int id, String nim, int courseId, int lecturerId, int semester,
                       int sikap, int uts, int uas, double score, String grade) {
        return krsDAO.update(id, nim, courseId, lecturerId, semester, sikap, uts, uas, score, grade);
    }

    public int delete(int id) { return krsDAO.delete(id); }
    public List<Object[]> getAllKRS() { return krsDAO.getAllKRS(); }
}
